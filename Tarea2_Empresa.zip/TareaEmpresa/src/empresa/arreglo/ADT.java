package empresa.arreglo;
import adts.Arreglo;

public class ADT {
	 String nombreEmpresa;
	    Arreglo<Trabajadores> nomina;
	    String rutaArchivo;

	    public ADT(String ruta) {
	        this.rutaArchivo=ruta;
	        
	    }

}
