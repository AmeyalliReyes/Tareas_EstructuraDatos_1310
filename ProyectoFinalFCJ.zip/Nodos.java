
public class Nodos {
	
	Nodos nodoUno; 
	Nodos nodoDos; 
	int n; 
	
	
	
	public Nodos(int n) {
		this.n= n; 
		
		
	}
	
	public int getn() {
		return this.n; 
	}
	
	public Nodos getnodoUno() {
		return this.nodoUno; 
	}
	
	public Nodos getnodoDos() {
		return this.nodoDos; 
	}
	
	public void add (int nd) {
		if(nd<this.n) {
			if(this.nodoUno==null) {
				this.nodoUno= new Nodos(nd); 
				
			}else {
				this.nodoUno.add(nd);
				
				
				
			}
		}else {
			if(this.nodoDos==null) {
				this.nodoDos= new Nodos(nd); 
				
			}else {
				this.nodoDos.add(nd);
			}
				
			
			
		}
		
		
		
		
		
		
		
	}

}
