
public class MainTreeMap {
	public static void main(String[] args) {
		TreeMap tree=new TreeMap();
		
		tree.add(55);
		tree.add(9);
		tree.add(32);
		tree.add(66);
		tree.add(100);
		tree.add(0);
		tree.add(12);
		tree.add(19);
		tree.add(983);
		tree.add(88);
		
		
		System.out.println("Inorden"); 
		tree.addIn(null);
		
		System.out.println("Preorden");
		tree.addPre();
		
		System.out.println("Posorden");
		tree.addPos(null);
		
		
	
	}
}
