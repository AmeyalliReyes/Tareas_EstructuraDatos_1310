
public class LinkedHashMap {
	java.util.HashMap<String, String> Map; 
	
	public LinkedHashMap(int map) {
		Map=new java.util.HashMap<>(); 
		
	}
	
	public void add(String m, String p) { //metod para agregar los elementos
		Map.put(m, p); 
	}
	
	public String ValueOf(String map) { //metodo para mostrar los elementos
		return Map.get(map); 
	}
	
	public void remove (String m) { // metodo para eliminar elementos 
		Map.remove(m); 
	}
	
	
	public static void main(String[] args) {
		LinkedHashMap nombres= new LinkedHashMap(5);
		
		nombres.add("1", "Andy"); //se utilzan este metodo add para agregar los nombres
		nombres.add("2", "Chris");
		nombres.add("3", "Saitan");
		nombres.add("4", "Illary");
		nombres.add("5", "Yalli");
		
		System.out.println("El nombre numero 1 es : "+ nombres.ValueOf("1")); //se utiliza el metodo ValueoF para mostrar los elemento
		System.out.println("El nombre numero 3 es : "+ nombres.ValueOf("3"));
		System.out.println("El nombre numero 4 es : "+ nombres.ValueOf("4"));
	}
	
	
	
	
	
	

}
