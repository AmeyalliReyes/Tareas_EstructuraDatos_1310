

public class HashMap {
	java.util.HashMap<String, String> Map; 
	
	public HashMap(int hm) { //constructor
		Map= new java.util.HashMap<>();
		
	}
	
	public void add(String m, String p) { //para agregar elementos se utiliza el metodo put
		Map.put(m, p); 
	}
	
	public String ValueOf(String m) { //almacenamiento de elementos
		return Map.get(m); 
	}
	
	public void remove(String map) { //remover elementos
		Map.remove(map); 
	}
	
	
public static void main(String[] args) {
		
		HashMap bandas=new HashMap(5);
		
		bandas.add("uno", "miw");
		bandas.add("dos", "bvb");
		bandas.add("tres", "rm");
		bandas.add("cuatro", "avenged");
		bandas.add("cinco", "robz");
		
		System.out.println("El uno es: "+bandas.ValueOf("uno")); 
		System.out.println("El dos es: "+bandas.ValueOf("dos")); 
		System.out.println("El cinco es: "+bandas.ValueOf("cinco")); 
	}
	
	
	

}
