
public class TreeMap {
	Nodos uno; 
	
	public TreeMap() { //constructor
		this.uno=null; 
	}
	
	public void add(int wt) {
		if(this.uno==null) {
			this.uno=new Nodos(wt); 
		}else {
			this.uno.add(wt);
			
		}
		
		
	}
	
	public void addPre() { // acomodar los elemtos en preorden
		this.pre(this.uno); 
	}
	
	public void pre(Nodos nd) {
		if(nd==null) {
			return; 
		}else {
			System.out.print(nd.getn()+ ", ");
			pre((nd.getnodoUno())); 
			pre(nd.getnodoDos()); 
			
		}
	}
	
	public void addIn(Nodos nd) { //agregar los elementos en inorden 
		this.in(this.uno);
	}
	public void in(Nodos nd) {
		if(nd==null) {
			return; 
		}else {
			in((nd.getnodoUno())); 
			in(nd.getnodoDos()); 
			
		}
		
		
	}
	
	public void addPos(Nodos nd) { //agregar los elementos en posorden
		this.pos(this.uno);
	}
	
	public void pos(Nodos nd) {
		if(nd==null) {
			return; 
		}else {
			pos((nd.getnodoUno()));
			
			pos(nd.getnodoDos()); 
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	

}
