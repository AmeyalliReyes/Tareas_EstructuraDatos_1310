package listas.ligadas;

public class Principal {
	public static void main (String args[]) {
		ListasEnlazadas lista=new ListasEnlazadas();
		
		System.out.println("Esta vacia: " +lista.estaVacia());
		
		lista.adrPrimero("Biersack"); 
		lista.adrPrimero(1990);
		lista.adrPrimero("BVB"); 
		lista.adrPrimero(26);
		
		lista.eliminar(2);
		
		System.out.println("Primer elemento: "+lista.obtener(0)); 
		System.out.println("Segundo elemento: "+lista.obtener(2));
		System.out.println("Ultimo elemento: "+lista.obtener(lista.tam()-1));
		
		System.out.println("Esta vacia: " +lista.estaVacia());
		System.out.println("Tamañao: "+ lista.tam());
		
		
		
	
	}

}
