package listas.ligadas;

public class Nodo {
	Object valor;
	Nodo siguiente; 
	
	public Nodo(Object valor) {
		this.valor=valor;
		this.siguiente=siguiente;
		
	}
	
	public void enlazarSiguiente(Nodo n) {
		siguiente=n; 
		
	}
	
	public Nodo obtenerSiguiente() {
		return siguiente; 
	}
	
	public Object ObtenerValor() {
		return valor; 
	}
	

}
