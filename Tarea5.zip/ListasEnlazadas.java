package listas.ligadas;

public class ListasEnlazadas {
	Nodo head; 
	int tam; 
	
	public ListasEnlazadas() {
		head=null; 
		tam=0; 
	}
	
	public Object obtener(int index) {
		int cont=0; 
		Nodo tim=head; 
		while(cont<index) {
			tim=tim.obtenerSiguiente();
			cont++; 
		}
		return tim.ObtenerValor(); 
	}
	
	public void adrPrimero(Object obj) {
		if(head==null) {
			head=new Nodo(obj); 
		}
		else {
			Nodo temp=head;
			Nodo nuevo=new Nodo(obj); 
			nuevo.enlazarSiguiente(temp);
			head=nuevo; 
		}
		tam++;
	}
	public int tam() {
		return tam; 
	}
	
	
	public boolean estaVacia() {
		return(head==null)?true:false; 
	}
	
	public void eliminarPrimero() {
		head=head.obtenerSiguiente();
		tam--; 
	}
	public void eliminar(int index) {
		if(index==0) {
			head=head.obtenerSiguiente();
		}
		else {
	
		int cont=0; 
		Nodo temp=head; 
		while(cont<index -1) {
			temp=temp.obtenerSiguiente();
			cont++;
		}
		temp.enlazarSiguiente(temp.obtenerSiguiente().obtenerSiguiente());
		}
		tam--; 
	}
	

}
