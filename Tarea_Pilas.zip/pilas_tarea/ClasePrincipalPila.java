package pilas_tarea;

public class ClasePrincipalPila {
	public static void main (String[] argg) {
		
		Stack pila=new Stack();
		
		pila.Push(50);
		pila.Push(16);
		pila.Push(66);
		
		
		System.out.println("El ultimo elemento de la pila es: ", +pila.Peek());
		
		
		while(pila.isEmpty()==false) {
			System.out.println(pila.Pop());
		}
		
		
		
		
		
		
	}

}
