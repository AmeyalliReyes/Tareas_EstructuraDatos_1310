package pilas_tarea;

public class Stack {
	private Nodo ultValIngresado;
	int tam=0; 
	String lista=""; 
	
	public Stack() {
		ultValIngresado=null; 
		tam=0; 
	}
	
	public int Length() {
		return tam; 
	}
	
	public boolean isEmpty() {
		return ultValIngresado==null; 
	}
	
	public void Push(int nodo) {
		Nodo nuevoNodo=new Nodo(nodo); 
		nuevoNodo.sig=ultValIngresado;
		ultValIngresado=nuevoNodo; 
		tam++; 
	}
	
	public int Pop() {
		int aux=ultValIngresado.info;
		ultValIngresado=ultValIngresado.sig; 
		tam--;
		return aux; 
	}
	
	public Nodo Peek() {
		return ultValIngresado; 
		
	}

	@Override
	public String toString() {
		return "Stack [Length()=" + Length() + ", isEmpty()=" + isEmpty() + ", Pop()=" + Pop() + ", Peek()=" + Peek()
				+ "]";
	}

	
	
	
	
	

}
