package pilas_tarea;

public class Nodo {
	int info;
	Nodo sig; 
	
	public Nodo(int valor) {
		info=valor;
		sig=null; 
		
	}

}
