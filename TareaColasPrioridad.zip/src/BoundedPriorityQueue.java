import tarea.colas.Nodo;

public class BoundedPriorityQueue {
	private Nodo inCola;
	private Nodo finCola; 
	String Cola=""; 
	
	public BoundedPriorityQueue() {
		inCola=null;
		finCola=null; 
	}
	
	public boolean is_empty() {
		if(inCola==null) {
			return true; 
		}else {
			return false; 
		}
	}
	
	public void length() {
		Nodo rec=inCola;
		String colaInv=""; 
		
		while(rec!=null) {
			Cola+= rec.info;
			rec=rec.sig; 
		}
		String cadena[]= Cola.split(" "); 
		
		for(int i=cadena.length -1; i>=0; i--) {
			colaInv += " " +cadena[i]; 
			
		}
		
	}
	
	public void enqueue(int inf)
	{
		Nodo nNodo=new Nodo(); 
		nNodo.info=inf; 
		nNodo.sig= null; 
		
		if(is_empty()) {
			inCola=nNodo; 
			finCola=nNodo; 
		}else {
			finCola.sig= nNodo;
			finCola=nNodo; 
		}
		
		
	}
	
	public int dequeue() {
		if(!is_empty()) {
			int inf=inCola.info;
			
			if(inCola==finCola) {
				inCola=null;
				finCola=null; 
			}else {
				inCola=inCola.sig;
			}
			return inf; 
		}else {
			return 0; 
		}
		
	}

	@Override
	public String toString() {
		return "Colas [is_empty()=" + is_empty() + ", dequeue()=" + dequeue() + "]";
	}
	

}
