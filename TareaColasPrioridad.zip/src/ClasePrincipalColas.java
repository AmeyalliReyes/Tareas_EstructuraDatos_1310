

public class ClasePrincipalColas {
	public static void main (String[] args) {
		BoundedPriorityQueue pq= new BoundedPriorityQueue();
		
		pq.enqueue("Maestre"); 
		pq.enqueue("niñas"); 
		pq.enqueue("niños"); 
		pq.enqueue("mecanico"); 
		pq.enqueue("hombres"); 
		pq.enqueue("vigia"); 
		pq.enqueue("capitan");
		pq.enqueue("timonel");
		pq.enqueue("mujeres"); 
		pq.enqueue("tercera edad");
		
		
		System.out.println(pq); 
		
		pq.dequeue();
		System.out.println(pq); 
		
		
		
	}

}
