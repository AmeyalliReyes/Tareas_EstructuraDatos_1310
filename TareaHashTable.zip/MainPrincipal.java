package tarea.hash.table;

import java.util.Hashtable;

public class MainPrincipal {
	HashTableADT hashTable=new HashTableADT(10);
	String[] elem= {"50", "66", "140", "3", "15", "78", "63", "22"};
	
	hashTable.add(elem, hashTable.arr); 
	hashTable.valueOf();
	
	String enc=hashTable.buscarCl("134"); 
	String enc1=hashTable.buscarCl("50"); 
	String enc2=hashTable.buscarCl("66"); 
	
	  if(enc==null) {
		  System.out.println("Elemento: "+ enc+ "no se encuentra en la tabla"); 
		  
	  }
	
			

}
