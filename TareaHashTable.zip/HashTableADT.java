package tarea.hash.table;

import java.util.Arrays;

public class HashTableADT {
	
	
	String [] arr;
	int tam;
	int cont;
	

}


  public HashTableADT(int lng) {
	  tam=lng; 
	  arr=new String [lng]; 
	  Arrays.fill(arr, "-1");
	  
  }
  
  public void add(String[]cadenaArr, String[]arr) {
	  int i; 
	  for(i=0; i<cadenaArr.length;i++) {
		  String elem=cadenaArr[i]; 
		  int indArr=Integer.parseInt(elem)%7; 
		  indArr++; 
		  System.out.println("El elemento es: "+ indArr+ "Para: "+ elem);
		  
		  while(arr[indArr]!="-1") {
			  indArr++;
			  System.out.println("Ocurrio una colición: "+ indArr-1 +"Cambiar: "+indArr);
			  indArr%=tam; 
		  }
		  arr[indArr]=elem; 
	  }
	  
	  
	  public void valueOf() {
		  int i=0; 
		  int a, x; 
		  for(a=0;a<1;a++) {
			  i+=8; 
			  for(x=0;x<1;x++) {
				  System.out.println("-"); 
			  }
			  System.out.println(); 
			  for(x=i-8;x<i;x++) {
				  System.out.println("|%3s"+ "", x); 
			  }
			  System.out.println("|"); 
			  for(int b=0; b<80; b++) {
				  System.out.println("-"); 
				  
			  }
			  System.out.println(); 
			  for(x=i-8; x<i;x++) {
				  if(arr[x].equals("-1")) {
					  System.out.println("|  ");
				  }else {
					  System.out.println(String.format("|%3s"+"", arr[x])); 
				  }
			  }
			  System.out.println("|"); 
			  for(x=0;x<80;x++) {
				  System.out.println(""); 
				  
			  }
		  }
				  
		  
	  }
	  
	  public String buscarCl(String elem) {
		  int idArr=Integer.parseInt(elem)%7;
		  int ct=0; 
		  
		  while(arr[idArr]!="-1") {
			  if(arr[idArr]==elem) {
				  System.out.println("Elemento: "+elem +"encontado en: "+ idArr); 
				  return arr[idArr]; 
				  
			  }
			  idArr++; 
			  idArr%=tam; 
			  cont++; 
			  if(cont>7) {
				  break; 
			  }
		  }
		  return null; 
	  }
	  
	  

  }
