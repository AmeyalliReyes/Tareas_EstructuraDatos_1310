package tarea.colas;



public class ClasePrincipalColas {
	public static void main (String[] args) {
            Colas cola=new Colas();
		
		cola.enqueue(10);
		cola.enqueue(66);
		cola.enqueue(15);
		cola.enqueue(45);
		cola.enqueue(12);
		
		System.out.println("Elementos de la cola: " +cola.length());
		
		
		
		while(cola.is_empty()==false) {
			System.out.println(cola.dequeue());
		}
		
	}

}
