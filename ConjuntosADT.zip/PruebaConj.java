package conjuntos.adt;

import java.util.Iterator;
import java.util.Scanner;

public class PruebaConj {
	public static void main(String[] args) {
		Scanner leer=new Scanner(System.in); 
		System.out.println("ingresar numero de elementos del conjunto a: ");
		int longiA=leer.nextInt();
		System.out.println("ingresar numero de elemntos del conjunto b: ");
		int longiB=leer.nextInt();
		
		int []a=new int [longiA]; 
		int []b=new int[longiB];
		
		System.out.println("Ingresar elementos de a: ");
		for (int i = 0; i < a.length; i++) {
			
			a[i]=leer.nextInt(); 
		}
		System.out.println("Ingresar elementos de b: ");
		for (int i = 0; i < b.length; i++) {
			
			b[i]=leer.nextInt(); 
		}
		ConjuntosADT  un= new ConjuntosADT(); 
		int [] U=un.Union(a, b); 
		ConjuntosADT inter=new ConjuntosADT();
		int [] In=inter.Interseccion(a, b); 
		
	System.out.println("Elementos de la union: "); 
		for(int i=0;i< U.length; i++) {
			System.out.println(U); 
			
			
		}
		System.out.println("Elementos de la intersecciom: "); 
		for(int i=0; i<In.length;i++) {
			System.out.println(In[i]); 
		}
		
	}
}
