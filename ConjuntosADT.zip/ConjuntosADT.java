package conjuntos.adt;

import java.util.ArrayList;

public class ConjuntosADT<T> {
	ArrayList<T> conjunto;
	
	public ConjuntosADT() {
		
		
	}
	
	public int longitud() {
        return this.conjunto.size();
    }
	
	public static Boolean contiene( int[] Conjunto, int Elemento)
	{
		Boolean contiene= false; 
		for(int i=0; i< Conjunto.length;i++) {
			if(Conjunto[i]==Elemento) {
				contiene=true; 
			}
		}
		return contiene; 
	}
	
	public static int[] Union(int[]a, int[] b )
	{
		int[] Un= new int[a.length + b.length]; 
		for(int i=0; i<a.length;i++) {
			Un[i]=a[i]; 
		}
		int x=0, y=0; 
		for(int i=0; i<b.length;i++) {
			if(contiene(Un, b[i])==false) {
				Un[a.length+x]=b[i]; 
				x++; 
			}
			else
			{
				y++; 
			}
		
		}
		int[] auxi=Un;
		Un=new int[auxi.length-y]; 
		for(int i=0; i<Un.length; i++) {
			Un[i]=auxi[i]; 
			
		}
		return Un; 
	}
	
	public static int[] Interseccion(int[]a, int[]b) {
		int bvb=0; 
		for(int i=0; i<a.length;i++) {
			if(contiene (b,a[i])==true) {
				bvb++; 
			}
		}
		int[] I=new int [bvb];
		int x=0; 
		for(int i=0; i<a.length;i++) {
			if(contiene(b, a[i])==true) {
				I[x]=a[i]; 
				x++; 
			}
		}
		return I; 
	}
	 public boolean esSubConjunto(ConjuntosADT<T> otroConjunto) {
	        if(longitud() > otroConjunto.longitud()){
	            return false;
	        }
	        for(T elemento : this.conjunto) {
	            if(!otroConjunto.contiene(elemento)) {
	                return false;
	            }
	        }
	        return true;
	    }
	 public void eliminar(T elemento) {
	        this.conjunto.remove(elemento);
	    }
	

}
